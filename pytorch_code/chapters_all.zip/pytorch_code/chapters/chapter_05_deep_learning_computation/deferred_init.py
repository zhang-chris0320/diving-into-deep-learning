"""deferred-init: 深度学习计算"""

# Generated from the PyTorch tab of D2L Chinese v2.0.0.
# The d2l namespace has been removed; shared support lives in common.py.
from pathlib import Path
import sys
_ROOT = Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import math
import random
import time
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.nn import functional as F
from torch.utils import data
import torchvision
from torchvision import transforms
from PIL import Image
from matplotlib import pyplot as plt
from IPython import display
import common as native

# PyTorch's LazyLinear is the native equivalent of deferred initialization.

def get_net():
    return nn.Sequential(nn.LazyLinear(256), nn.ReLU(), nn.LazyLinear(10))

net = get_net()
print(net)

# Parameters become materialized after the first forward pass.
X = torch.rand(2, 20)
Y = net(X)
print(net)
print(Y.shape)
