"""rnn: 循环神经网络"""

# Generated from the PyTorch tab of D2L Chinese v2.0.0.
# The d2l namespace has been removed; shared support lives in common.py.
from pathlib import Path
import sys
_ROOT = Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import math
import random
import time
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.nn import functional as F
from torch.utils import data
import torchvision
from torchvision import transforms
from PIL import Image
from matplotlib import pyplot as plt
from IPython import display
import common as native

import common as native
import torch

X, W_xh = native.normal(0, 1, (3, 1)), native.normal(0, 1, (1, 4))
H, W_hh = native.normal(0, 1, (3, 4)), native.normal(0, 1, (4, 4))
native.matmul(X, W_xh) + native.matmul(H, W_hh)

native.matmul(native.concat((X, H), 1), native.concat((W_xh, W_hh), 0))
