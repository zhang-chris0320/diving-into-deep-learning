"""convexity: 优化算法"""

# Generated from the PyTorch tab of D2L Chinese v2.0.0.
# The d2l namespace has been removed; shared support lives in common.py.
from pathlib import Path
import sys
_ROOT = Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import math
import random
import time
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.nn import functional as F
from torch.utils import data
import torchvision
from torchvision import transforms
from PIL import Image
from matplotlib import pyplot as plt
from IPython import display
import common as native

import common as native
import numpy as np
from mpl_toolkits import mplot3d
import torch

f = lambda x: 0.5 * x**2  # 凸函数
g = lambda x: native.cos(np.pi * x)  # 非凸函数
h = lambda x: native.exp(0.5 * x)  # 凸函数

x, segment = native.arange(-2, 2, 0.01), native.tensor([-1.5, 1])
native.use_svg_display()
_, axes = native.plt.subplots(1, 3, figsize=(9, 3))
for ax, func in zip(axes, [f, g, h]):
    native.plot([x, segment], [func(x), func(segment)], axes=ax)

f = lambda x: (x - 1) ** 2
native.set_figsize()
native.plot([x, segment], [f(x), f(segment)], 'x', 'f(x)')
