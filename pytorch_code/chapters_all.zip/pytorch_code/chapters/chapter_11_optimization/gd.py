"""gd: 优化算法"""

# Generated from the PyTorch tab of D2L Chinese v2.0.0.
# The d2l namespace has been removed; shared support lives in common.py.
from pathlib import Path
import sys
_ROOT = Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import math
import random
import time
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.nn import functional as F
from torch.utils import data
import torchvision
from torchvision import transforms
from PIL import Image
from matplotlib import pyplot as plt
from IPython import display
import common as native

import common as native
import numpy as np
import torch

def f(x):  # 目标函数
    return x ** 2

def f_grad(x):  # 目标函数的梯度(导数)
    return 2 * x

def gd(eta, f_grad):
    x = 10.0
    results = [x]
    for i in range(10):
        x -= eta * f_grad(x)
        results.append(float(x))
    print(f'epoch 10, x: {x:f}')
    return results

results = gd(0.2, f_grad)

def show_trace(results, f):
    n = max(abs(min(results)), abs(max(results)))
    f_line = native.arange(-n, n, 0.01)
    native.set_figsize()
    native.plot([f_line, results], [[f(x) for x in f_line], [
        f(x) for x in results]], 'x', 'f(x)', fmts=['-', '-o'])

show_trace(results, f)

show_trace(gd(0.05, f_grad), f)

show_trace(gd(1.1, f_grad), f)

c = native.tensor(0.15 * np.pi)

def f(x):  # 目标函数
    return x * native.cos(c * x)

def f_grad(x):  # 目标函数的梯度
    return native.cos(c * x) - c * x * native.sin(c * x)

show_trace(gd(2, f_grad), f)

def train_2d(trainer, steps=20, f_grad=None):  #@save
    """用定制的训练机优化2D目标函数"""
    # s1和s2是稍后将使用的内部状态变量
    x1, x2, s1, s2 = -5, -2, 0, 0
    results = [(x1, x2)]
    for i in range(steps):
        if f_grad:
            x1, x2, s1, s2 = trainer(x1, x2, s1, s2, f_grad)
        else:
            x1, x2, s1, s2 = trainer(x1, x2, s1, s2)
        results.append((x1, x2))
    print(f'epoch {i + 1}, x1: {float(x1):f}, x2: {float(x2):f}')
    return results

def show_trace_2d(f, results):  #@save
    """显示优化过程中2D变量的轨迹"""
    native.set_figsize()
    native.plt.plot(*zip(*results), '-o', color='#ff7f0e')
    x1, x2 = native.meshgrid(native.arange(-5.5, 1.0, 0.1),
                          native.arange(-3.0, 1.0, 0.1))
    native.plt.contour(x1, x2, f(x1, x2), colors='#1f77b4')
    native.plt.xlabel('x1')
    native.plt.ylabel('x2')

def f_2d(x1, x2):  # 目标函数
    return x1 ** 2 + 2 * x2 ** 2

def f_2d_grad(x1, x2):  # 目标函数的梯度
    return (2 * x1, 4 * x2)

def gd_2d(x1, x2, s1, s2, f_grad):
    g1, g2 = f_grad(x1, x2)
    return (x1 - eta * g1, x2 - eta * g2, 0, 0)

eta = 0.1
show_trace_2d(f_2d, train_2d(gd_2d, f_grad=f_2d_grad))

c = native.tensor(0.5)

def f(x):  # O目标函数
    return native.cosh(c * x)

def f_grad(x):  # 目标函数的梯度
    return c * native.sinh(c * x)

def f_hess(x):  # 目标函数的Hessian
    return c**2 * native.cosh(c * x)

def newton(eta=1):
    x = 10.0
    results = [x]
    for i in range(10):
        x -= eta * f_grad(x) / f_hess(x)
        results.append(float(x))
    print('epoch 10, x:', x)
    return results

show_trace(newton(), f)

c = native.tensor(0.15 * np.pi)

def f(x):  # 目标函数
    return x * native.cos(c * x)

def f_grad(x):  # 目标函数的梯度
    return native.cos(c * x) - c * x * native.sin(c * x)

def f_hess(x):  # 目标函数的Hessian
    return - 2 * c * native.sin(c * x) - x * c**2 * native.cos(c * x)

show_trace(newton(), f)

show_trace(newton(0.5), f)
