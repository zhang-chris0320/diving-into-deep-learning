"""momentum: 优化算法"""

# Generated from the PyTorch tab of D2L Chinese v2.0.0.
# The d2l namespace has been removed; shared support lives in common.py.
from pathlib import Path
import sys
_ROOT = Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import math
import random
import time
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.nn import functional as F
from torch.utils import data
import torchvision
from torchvision import transforms
from PIL import Image
from matplotlib import pyplot as plt
from IPython import display
import common as native

import common as native
import torch

eta = 0.4
def f_2d(x1, x2):
    return 0.1 * x1 ** 2 + 2 * x2 ** 2
def gd_2d(x1, x2, s1, s2):
    return (x1 - eta * 0.2 * x1, x2 - eta * 4 * x2, 0, 0)

native.show_trace_2d(f_2d, native.train_2d(gd_2d))

eta = 0.6
native.show_trace_2d(f_2d, native.train_2d(gd_2d))

def momentum_2d(x1, x2, v1, v2):
    v1 = beta * v1 + 0.2 * x1
    v2 = beta * v2 + 4 * x2
    return x1 - eta * v1, x2 - eta * v2, v1, v2

eta, beta = 0.6, 0.5
native.show_trace_2d(f_2d, native.train_2d(momentum_2d))

eta, beta = 0.6, 0.25
native.show_trace_2d(f_2d, native.train_2d(momentum_2d))

native.set_figsize()
betas = [0.95, 0.9, 0.6, 0]
for beta in betas:
    x = native.numpy(native.arange(40))
    native.plt.plot(x, beta ** x, label=f'beta = {beta:.2f}')
native.plt.xlabel('time')
native.plt.legend();

def init_momentum_states(feature_dim):
    v_w = native.zeros((feature_dim, 1))
    v_b = native.zeros(1)
    return (v_w, v_b)

def sgd_momentum(params, states, hyperparams):
    for p, v in zip(params, states):
        with torch.no_grad():
            v[:] = hyperparams['momentum'] * v + p.grad
            p[:] -= hyperparams['lr'] * v
        p.grad.data.zero_()

def train_momentum(lr, momentum, num_epochs=2):
    native.train_ch11(sgd_momentum, init_momentum_states(feature_dim),
                   {'lr': lr, 'momentum': momentum}, data_iter,
                   feature_dim, num_epochs)

data_iter, feature_dim = native.get_data_ch11(batch_size=10)
train_momentum(0.02, 0.5)

train_momentum(0.01, 0.9)

train_momentum(0.005, 0.9)

trainer = torch.optim.SGD
native.train_concise_ch11(trainer, {'lr': 0.005, 'momentum': 0.9}, data_iter)

lambdas = [0.1, 1, 10, 19]
eta = 0.1
native.set_figsize((6, 4))
for lam in lambdas:
    t = native.numpy(native.arange(20))
    native.plt.plot(t, (1 - eta * lam) ** t, label=f'lambda = {lam:.2f}')
native.plt.xlabel('time')
native.plt.legend();
