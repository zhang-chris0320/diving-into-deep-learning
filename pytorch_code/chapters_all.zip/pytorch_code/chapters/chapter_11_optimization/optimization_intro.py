"""optimization-intro: 优化算法"""

# Generated from the PyTorch tab of D2L Chinese v2.0.0.
# The d2l namespace has been removed; shared support lives in common.py.
from pathlib import Path
import sys
_ROOT = Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import math
import random
import time
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.nn import functional as F
from torch.utils import data
import torchvision
from torchvision import transforms
from PIL import Image
from matplotlib import pyplot as plt
from IPython import display
import common as native

import common as native
import numpy as np
from mpl_toolkits import mplot3d
import torch

def f(x):
    return x * native.cos(np.pi * x)

def g(x):
    return f(x) + 0.2 * native.cos(5 * np.pi * x)

def annotate(text, xy, xytext):  #@save
    native.plt.gca().annotate(text, xy=xy, xytext=xytext,
                           arrowprops=dict(arrowstyle='->'))

x = native.arange(0.5, 1.5, 0.01)
native.set_figsize((4.5, 2.5))
native.plot(x, [f(x), g(x)], 'x', 'risk')
annotate('min of\nempirical risk', (1.0, -1.2), (0.5, -1.1))
annotate('min of risk', (1.1, -1.05), (0.95, -0.5))

x = native.arange(-1.0, 2.0, 0.01)
native.plot(x, [f(x), ], 'x', 'f(x)')
annotate('local minimum', (-0.3, -0.25), (-0.77, -1.0))
annotate('global minimum', (1.1, -0.95), (0.6, 0.8))

x = native.arange(-2.0, 2.0, 0.01)
native.plot(x, [x**3], 'x', 'f(x)')
annotate('saddle point', (0, -0.2), (-0.52, -5.0))

x, y = native.meshgrid(
    native.linspace(-1.0, 1.0, 101), native.linspace(-1.0, 1.0, 101))
z = x**2 - y**2

ax = native.plt.figure().add_subplot(111, projection='3d')
ax.plot_wireframe(x, y, z, **{'rstride': 10, 'cstride': 10})
ax.plot([0], [0], [0], 'rx')
ticks = [-1, 0, 1]
native.plt.xticks(ticks)
native.plt.yticks(ticks)
ax.set_zticks(ticks)
native.plt.xlabel('x')
native.plt.ylabel('y');

x = native.arange(-2.0, 5.0, 0.01)
native.plot(x, [native.tanh(x)], 'x', 'f(x)')
annotate('vanishing gradient', (4, 1), (2, 0.0))
