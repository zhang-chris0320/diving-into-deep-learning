"""multiscale-object-detection: 计算机视觉"""

# Generated from the PyTorch tab of D2L Chinese v2.0.0.
# The d2l namespace has been removed; shared support lives in common.py.
from pathlib import Path
import sys
_ROOT = Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import math
import random
import time
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.nn import functional as F
from torch.utils import data
import torchvision
from torchvision import transforms
from PIL import Image
from matplotlib import pyplot as plt
from IPython import display
import common as native

import common as native
import torch

img = native.plt.imread('../img/catdog.jpg')
h, w = img.shape[:2]
h, w

def display_anchors(fmap_w, fmap_h, s):
    native.set_figsize()
    # 前两个维度上的值不影响输出
    fmap = native.zeros((1, 10, fmap_h, fmap_w))
    anchors = native.multibox_prior(fmap, sizes=s, ratios=[1, 2, 0.5])
    bbox_scale = native.tensor((w, h, w, h))
    native.show_bboxes(native.plt.imshow(img).axes,
                    anchors[0] * bbox_scale)

display_anchors(fmap_w=4, fmap_h=4, s=[0.15])

display_anchors(fmap_w=2, fmap_h=2, s=[0.4])

display_anchors(fmap_w=1, fmap_h=1, s=[0.8])
