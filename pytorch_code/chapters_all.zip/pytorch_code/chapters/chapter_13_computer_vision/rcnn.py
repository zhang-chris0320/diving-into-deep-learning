"""rcnn: 计算机视觉"""

# Generated from the PyTorch tab of D2L Chinese v2.0.0.
# The d2l namespace has been removed; shared support lives in common.py.
from pathlib import Path
import sys
_ROOT = Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

import math
import random
import time
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.nn import functional as F
from torch.utils import data
import torchvision
from torchvision import transforms
from PIL import Image
from matplotlib import pyplot as plt
from IPython import display
import common as native

import torch
import torchvision

X = torch.arange(16.).reshape(1, 1, 4, 4)
X

rois = torch.Tensor([[0, 0, 0, 20, 20], [0, 0, 10, 30, 30]])

torchvision.ops.roi_pool(X, rois, output_size=(2, 2), spatial_scale=0.1)
